  $(function() {
    $("#datepicker").datepicker({
     changeMonth:true,
     changeYear:true,
     yearRange:"-100:+0",
     dateFormat:"dd.mm.yy"
  });
  });
    $(function() {
    $( "#datepicker1" ).datepicker({
     changeMonth:true,
     changeYear:true,
     yearRange:"-100:+0",
     dateFormat:"dd.mm.yy"
  });
  });
$(function() {
    $( "#datepicker2" ).datepicker({
     changeMonth:true,
     changeYear:true,
     yearRange:"-100:+0",
     dateFormat:"dd.mm.yy"
  });
  });
$(function() {
    $( "#datepicker3" ).datepicker({
     changeMonth:true,
     changeYear:true,
     yearRange:"-100:+0",
     dateFormat:"dd.mm.yy"
  });
  });
$(function() {
    $( "#datepicker4" ).datepicker({
     changeMonth:true,
     changeYear:true,
     yearRange:"-100:+0",
     dateFormat:"dd.m.yy"
  });
  });




